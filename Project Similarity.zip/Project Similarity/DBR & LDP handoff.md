# DBR/LDP decision: session handoff brief

**Purpose.** Port full context to a session that has none. Everything here comes from a team meeting on 2026-08-31, the current draft of [DBR & LDP integration.md](DBR%20&%20LDP%20integration.md), and measured benchmark runs. Written 2026-08-31.

**This is an internal working document.** It is not the artifact going to the client. The client-facing artifact is `DBR & LDP integration.md`.

---

## 0. Read this first: two errors that keep propagating

**Option letters.** In `DBR & LDP integration.md`, **Option A is denormalizing DBR and LDP into the existing retrieval index. Option B is the dedicated SQL Agent service.** Several earlier summaries had these reversed. Always confirm against the doc before writing anything that names a letter.

**Terminology.** The house term for the natural-language-to-SQL component is **SQL Agent**. Not Text2SQL. Not NL2SQL. It appears wrongly in older notes. Watch for it hiding in table headers and metric labels.

---

## 1. The system, for someone who has never seen it

**Deployment.** The orchestrator, the project similarity tool, and the SQL Agent each run as their own container on OpenShift, managed by Kubernetes, autoscaling with a configurable replica ceiling per component.

**Project similarity** is a prompt flow. The orchestrator LLM invokes it as a tool by passing in the user prompt.

**Retrieval** runs on Azure AI Search using hybrid search with RRF ranking, feeding a RAG pipeline inside the project similarity tool.

**Index contents.** One denormalized document per project. Holds PSR, WPM, PECT, and Impact. Project documents and files are chunked, embedded, and indexed per project, so the tool does vector comparison plus keyword search. DBR and LDP are the data sources under discussion for addition.

**Ingestion.** An Azure Data Factory instance holds 16 pipelines. One orchestrator pipeline and one sub-pipeline matter for project similarity. It pulls from SharePoint, PECT (another SharePoint), and WPM (**sourced from Snowflake**, see section 6). It checks whether a file is already in blob storage, skips it if so, and loops by setting the next URL. Runtime is 30 minutes to 2 hours depending on new volume. It runs on a **daily schedule trigger**.

After extraction, a web dispatch step in the pipeline calls the OpenShift ingestion service, which does change detection, document parsing, chunking, embedding, and updates the dev index.

**Dev to prod replication is manual today.** Someone runs a script from a local VDI. The project similarity index is near 40 GB. Six concurrent workers gets replication to 1 to 2 hours. The other three indexes take 1 to 5 minutes. Greg has separately asked for this to be automated. That work is being handed to a colleague and is tracked elsewhere.

**The constraint driving everything: a 30 second end-to-end response time target.**

---

## 2. The decision

Serve DBR and LDP through a dedicated SQL Agent service, or denormalize both into the existing project similarity index.

**Option A, denormalize into the retrieval index.** DBR and LDP are project-scoped metadata, one record per project, the same shape as WPM and PECT which the index already holds. Retrieval becomes single hop. A compound question like "return all projects under Kinesis, then project the cost-benefit fields from their DBRs" resolves in one search against one index. Storing the fields in the same index also improves keyword recall, since a question mentioning a DBR or LDP term can match a project through BM25, where today that text is not in the index at all and the project cannot be found by those terms under any query.

**Option B, a separate SQL Agent.** Queries the database directly, so there is no ingestion pipeline and no staleness. Strong at exact aggregates, counts, grouping, and multi-table joins that a retrieval index cannot answer at all.

**The team leans toward Option A**, driven by response time. With a separate SQL Agent the orchestrator must run in sequence: call project similarity, wait, extract the returned project IDs, call the SQL Agent for DBR/LDP data on those projects, then combine. The data dependency rules out parallel dispatch.

**The accepted cost is coupling.** DBR and LDP fold into the project similarity service and stop being separately deployable or callable. A future product needing DBR alone has to query similarity search and discard the ranking. Triet named this as the biggest disadvantage and accepted it in exchange for latency and result quality.

---

## 3. Every measured number

From a colleague's SQL Agent prototype, run end to end on a local VCME environment before the team leaned away from that approach. They asked for the numbers to stay in the write-up regardless.

| Metric | Value |
|---|---|
| SQL Agent step | 15-20s (13s query generation, 1s execution) |
| End-to-end latency | ~40s, more than 50% attributable to LLM inference |
| Cost per query | $0.13 to $0.16 |

**Six LDP validation queries**, all returned correct results.

| # | Query | Result | Latency | Cost |
|---|---|---|---|---|
| 1 | Title and learning theme for all positive learnings | 2 cols, 5 rows | 46s | $0.14 |
| 2 | Which learning themes contain the most positive learnings? | All 5 tied at 1; 2 cols, 5 rows | 45s | $0.15 |
| 3 | Any learning themes with zero positive learnings? | 3 cols, 3 rows | 48s | $0.16 |
| 4 | Title, captured date, recommended actions where title matches "Pedro" | 3 cols, 3 rows | 46s | $0.15 |
| 5 | Row count of learnings | 10 rows in dbo.Learnings | 40s | $0.13 |
| 6 | Title, description, recommended actions where workId = 1011121 | 3 cols, 4 rows | 40s | $0.15 |

**Response quality was rated very good**, including analysis across multi-table joins. This belongs in the doc. Dismissing Option B on latency while acknowledging its quality is more credible than dismissing it wholesale.

**Numbers in the current comparison table that have no measurement behind them:**

- Option A best case, listed as ~35s. Triet states in conversation that a project-scoped query returns in **30 to 40 seconds including DBR and LDP in the same retrieval**. Source of that figure is unconfirmed. See open question Q2.
- Option A worst case, listed as ~90s on a large scan. Scenario undefined. See open question Q3.
- Option B worst case, listed as ~90s+, derived by doubling the 40s measurement. The doubling is wrong in principle, because the first call is similarity retrieval, not the SQL Agent. If similarity retrieval is faster than 40s, the true figure is lower.

**Three caveats a reviewer will raise about the six queries:**

1. Observed latency of 40 to 48 seconds already exceeds the 30 second target on a single call, before chaining anything.
2. Every query reads only LDP data. None of them exercise the two-hop compound path that motivates the entire decision.
3. `dbo.Learnings` holds 10 rows, so none of this says anything about production data volume.

---

## 4. People

| Name | Role in this decision |
|---|---|
| Greg | Client. Audience for the write-up. Approves or rejects the recommendation. |
| Bushra Chowdhury (she/her) | Team lead on the engagement. Drove the concerns-section requirement, owns the client relationship risk, builds the deck. |
| Triet | Author of the write-up. Owns the doc and the recommendation. |
| Hong | Built the SQL Agent prototype and produced all the benchmark numbers. |
| Matej | Reviewer, leaving for vacation after the Wednesday session. |
| Christine | Holds real LDP and DBR user questions. Asked to supply samples. |
| Vikas | Internal. Asked Bushra why the phase one design approval did not cover these questions. |

---

## 5. Bushra's requirements, and why they exist

She did not push back on the technical merits. She agreed with the recommendation. Her concern is entirely about what happens when Greg changes his mind later.

Her stated pattern: **Greg gives a direction, later reverses it, and then it reads as though the decision was the team's.** Her example is Work Delivery GPT. ADF was not available, so the team built the sync version. ADF arrived later, Greg asked for the rework, and the rework was not paid for. Her instruction is to write down the constraint that forced each decision, at the time, so the decision cannot be reassigned afterward.

She also raised that this proposal is **a significant architectural change relative to what was originally scoped**. Greg's original position was that the pipelines already exist and the team just ingests the data. If sub-30 seconds is a new requirement from Greg, in her view it belongs in a separate SOW rather than being absorbed silently. She is reading both SOWs to determine whether performance was ever promised.

Her required additions to the doc:

1. A concerns or requirements section **above** Options A and B, so the decision visibly answers each constraint
2. Performance, pipeline reuse, the Snowflake change, and the semantic layer as the four items
3. A date stamp with the platform state
4. A justification paragraph
5. A diagram, which she offered to build

Her closing position: **get Greg's explicit approval on the architecture, against the stated concerns.** Not tacit agreement in a meeting.

---

## 6. The Snowflake problem

Greg told Bushra that **Snowflake will stop allowing full database downloads within two to three months**, and that the Snowflake team says there is **no change detection or delta**, so any update means refreshing the entire database.

**Status: unverified by anyone on the team.** Nobody has seen it in writing. Triet has already sent Greg a question asking where the information comes from and where to find more detail. No response recorded yet.

**Why it is the highest-stakes open item.** Option A depends on bulk extraction from Snowflake. If bulk extraction is removed, Option A is not viable and Option B becomes the only path. The recommendation flips.

**A point that has not been made anywhere yet, and should be verified before it goes in the doc.** WPM is already sourced from Snowflake through the ADF pipeline **in production today**. If bulk extraction is removed, that breaks the existing project similarity index, not only the new proposal. That reframes the risk as a platform problem Greg owns rather than a flaw in the team's design. See open question Q4. If it holds, it is the single strongest sentence available for the doc.

**Bushra's read** is that this is a commercial move to keep the data inside Snowflake so Snowflake gets paid. She is skeptical of the claim on its face.

**Research still needed:** Snowflake release notes and deprecation announcements for the current and next quarter, whether the restriction covers `COPY INTO <location>` or external stage unloads specifically, and whether change tracking is genuinely unavailable. Snowflake has offered Streams and change tracking for years, so "no delta" is more plausibly a configuration state on the Exxon instance than a product limit. Worth asking neutrally so the record can be corrected without anyone being wrong in public.

---

## 7. The five agreed work items

### 7.1 Concerns section, above Options A and B

**Status: agreed. Draft available below, numbers need checking against the doc.**

Goes between the decision statement and Option A. Four items, each stating the concern and how the recommendation answers it.

The intent, in Triet's own words: document all constraints and requirements at the very beginning so they are the first thing Greg sees. That puts the decision on record as answering his constraints rather than expressing the team's preference.

Draft:

> ## Concerns this decision has to address
>
> **Response time.** The target is 30 seconds end to end. The SQL Agent prototype measured about 40 seconds on a single call, with the six LDP validation queries landing between 40 and 48 seconds. More than half of that is LLM inference, which no approach avoids. A compound question needs project resolution first and DBR/LDP retrieval second, and the data dependency between them rules out running the calls in parallel, so Option B compounds that latency. Option A answers a project-scoped question, including its DBR and LDP fields, in one search against one index.
>
> **Pipeline reuse.** The original scope assumed the existing ingestion pipeline would carry new data sources. Option A stays inside that pipeline and adds fields to a schema already in production. Option B adds a second service with its own deployment, evaluation, and maintenance.
>
> **Snowflake availability.** Option A depends on bulk data extraction from Snowflake. Greg has indicated this can be restricted within two to three months, and that Snowflake offers no delta so refreshes are full. As of 2026-08-31 the team has not confirmed this. If bulk extraction is removed, Option A is not viable and Option B becomes the only path. The team needs this confirmed by the Snowflake team before committing.
>
> **Semantic layer.** The term is being used two ways. One is column and table descriptions inside the SQL layer so the model can map a question onto the schema, which is only needed when names are not self-descriptive. The other is embedding-based retrieval over indexed content. Option A delivers the second. Option B needs the first, and only where the schema is poorly named. The team needs Greg to confirm which one he is asking for, because the two point at different options.

**Note the response time item is deliberately vague on Option A's number.** It cannot be tightened until Q2 is answered.

### 7.2 Date stamp and platform state

**Status: agreed, with the scope clarified.**

This is **not** a retroactive audit. It does not require reconstructing previous decisions. It is four sentences recording what the platform allows on the date this decision was made.

Draft:

> **Decision context as of 2026-08-31.** This recommendation reflects the platform as it stands today: the Exxon starter kit provides [see Q5], Snowflake permits bulk extraction, and ADF is available for scheduled ingestion. If any of these change, the comparison below needs to be revisited. A change in platform capability after this date is a new decision, not a defect in this one.

The last sentence is the one doing the work. Keep it verbatim.

### 7.3 Justification paragraph

**Status: agreed in principle, earlier draft was factually wrong. Rewrite needed.**

The earlier draft claimed Option A "is the only one that meets 30 seconds on compound questions." That is not supported. Triet's correction: for a query asking about a particular project, Option A returns in **30 to 40 seconds, and that already includes DBR and LDP in the same retrieval context**.

That range straddles the 30 second target rather than clearing it. **Strictly read, neither option meets sub-30.** Any justification paragraph has to be honest about that, because Greg or Matej will do the subtraction. See open question Q1 on whether 30 seconds is a hard requirement.

Shape the paragraph should take:

- Recommend Option A
- Response time is the deciding factor, and Option A is materially faster on the questions users actually ask, not that it clears the target outright
- Pipeline reuse points the same way
- Name the accepted cost yourself: DBR and LDP stop being separately callable, so a future product needing DBR alone has to query similarity search and discard the ranking
- State the condition: this holds as long as bulk Snowflake extraction stays available
- State the boundary: the SQL Agent remains the correct answer for aggregates, counts, grouping, and joins across tables that the index cannot serve

Naming the cost is what makes the rest credible.

### 7.4 Best fit row in the comparison table

**Status: agreed, no corrections.**

Move it to the top of the table or bold it. It is currently the second row. Hong's argument is that the user's actual questions decide this, not the architecture in the abstract.

- Option A: questions scoped to a project or a set of projects, where the answer is content already indexed. "Return all projects under Kinesis, then give me the cost-benefit fields from their DBRs."
- Option B: exact counts, aggregates, grouping, and joins across tables. "How many learnings were captured per theme last quarter."

Fix the unmeasured numbers while editing this table. See section 3.

### 7.5 Diagram

**Status: agreed. Bushra builds it, she needs the inputs today.**

Her reasoning: Greg will not follow the latency argument from a table. He needs to see one path with one hop and the other with two.

- Option A: user prompt, one hybrid search against the index with a filter, one LLM call, answer. One box in the middle.
- Option B: user prompt, orchestrator, project similarity to resolve which projects are involved, wait, extract the project IDs, call the SQL Agent for DBR/LDP on those IDs, combine, answer. Latency next to each hop.

**The sequential arrow is the entire point of the picture.** The second call cannot start until the first returns. That is what makes the compounding obvious.

---

## 8. Additional items from the transcript, not in the list of five

These came out of the meeting and relate directly to the decision or to protecting the team. None of them are in the five items above.

### 8.1 State that DBR and LDP will be keyword-indexed, not embedded

In the meeting Bushra asked whether Option A means downloading the database and vectorizing it. Triet's answer: download yes, vectorize no. The plan is to index the fields and use keyword search, because the descriptions in the metadata are short. Vectorization stays available if search accuracy turns out to need it.

**Why it must be written down.** The recall gain from Option A is limited to BM25 keyword matching. Vector search cannot reach DBR and LDP free text under this plan. If someone later asks why a semantically phrased DBR question missed, the answer needs to already be in the doc as a stated design choice, not discovered as a defect.

### 8.2 State the index freshness interval, and get it accepted

Option A serves DBR and LDP from the index, refreshed by an ADF pipeline on a daily trigger. Option B reads the live database. The comparison table has a data freshness row but no number in it.

**Nobody has asked Greg whether daily-stale DBR and LDP is acceptable.** If the answer is no, that is an argument for Option B that has not been weighed. Put the actual interval in the table and put the question to Greg.

### 8.3 State the full-refresh consequence if the no-delta claim holds

If Snowflake genuinely offers no change tracking, every ingestion run is a full pull rather than an incremental one. That changes ingestion runtime and cost for Option A, and it has to fit inside the existing daily ADF window alongside extraction. The existing OpenShift service does change detection at the document level, which limits re-embedding but does not reduce the extraction volume.

### 8.4 State the operational cost of growing the index

The project similarity index is already near 40 GB, and dev to prod replication takes 1 to 2 hours with six workers and is manual today. Adding DBR and LDP grows it further. This is a real cost of Option A and it is currently invisible in the doc. Greg has separately asked for the replication to be automated, which is being handed to a colleague.

### 8.5 Record where the 30 second target came from

Bushra is reading both SOWs to determine whether performance was ever promised. Her position is that if sub-30 is a new requirement from Greg, it belongs in a separate SOW rather than being absorbed. The doc should state the origin of the target rather than treating it as a given. This is blame protection: an unattributed requirement is one that can later be described as something the team invented and failed to meet.

### 8.6 State whether this is a change relative to the original scope

Greg's original position was that the pipelines exist and the team just ingests the data. Bushra reads the current proposal as a significant architectural change against that. The doc should say plainly whether the recommendation sits inside the original premise or departs from it, so nobody has to reconstruct that judgment later.

### 8.7 Record that the use cases were never supplied

Triet raised this repeatedly in the meeting: without the use cases the team is making assumptions nobody has confirmed. Hong made the same point from the technical side, that the user's actual questions decide the answer.

**The doc should state the assumption explicitly.** Something like: this recommendation assumes questions are predominantly project-scoped, because use cases were requested and not supplied as of this date. If that assumption is wrong, the recommendation changes. That single sentence converts a silent assumption into a documented open item.

Two questions to Greg get most of the way there:

- Will users ask about DBR and LDP on their own, or always in the context of a project already under discussion?
- Do any of these questions need counts, totals, or grouping across projects?

Christine has been asked separately for 10 to 15 real LDP and DBR questions with expected answers, to be run through the SQL Agent by Hong. That evidence fills the best fit row with data instead of judgment.

### 8.8 The semantic layer is a vocabulary collision, and should be put to Greg as a question

Hong's meaning: column and table descriptions inside the SQL implementation, needed only when column and table names are not self-descriptive. He ran his validation questions with no semantic layer at all and the model found the correct columns and tables on its own.

Triet's and Bushra's meaning: embedding-based similarity search.

Greg's usage: he says project similarity phase one had a semantic layer, then points at SQL column names, which is Hong's sense. He has used both.

**Frame it to Greg as a question about which he wants, never as a disagreement between team members.** Worth mentioning that the team has previously built an agent that samples column data to infer what a column holds and writes that back as column metadata, which is the answer if he means the SQL sense.

### 8.9 The scope split needs Greg to say it out loud

A reusable pipeline for ingesting and chatting with any structured or unstructured data in natural language is one product. Letting PMs chat comfortably about a specific project and its neighbors is a different product. The technical scope is not the same.

Greg wants generalized pipelines that ingest anything. Bushra's position is that generalizing costs performance, and that Greg needs to state that and approve it rather than have it absorbed quietly. Her framing is that the goals sound similar but are architecturally different, and that byproducts of one should not be assumed to generalize to the other.

### 8.10 Add an explicit approval section to the doc

This is the mechanism that makes everything else in section 5 work. Bushra's closing instruction was to get Greg's approval on the architecture, against the stated concerns, explicitly.

The doc should end with a short section naming exactly what Greg is being asked to approve and what he is being asked to confirm. Candidates: the recommendation itself, the accepted coupling cost, the index freshness interval, which meaning of semantic layer he wants, whether generalized pipelines are in scope, and the Snowflake position. A signed-off list is what stops a reversal from landing on the team.

### 8.11 Add cost to the comparison table

$0.13 to $0.16 per SQL Agent query is measured and currently appears only in the sample runs table. There is no equivalent figure for Option A, which is itself worth noting.

---

## 9. Open questions the next session must resolve

Ordered by how much they block. Q1 through Q4 change what the doc says.

**Q1. Is the 30 second target a hard requirement or an aspiration?** Where did it come from, and is it in either SOW? Option A at 30 to 40 seconds and Option B at 40 to 48 seconds both straddle or exceed it. If it is hard, neither option passes as measured and the doc has to say so. If it is a goal, the framing is relative rather than pass or fail. Bushra is checking the SOWs.

**Q2. Where does Option A's 30 to 40 second figure come from?** Measured, estimated, or inferred? The table says ~35s. The SQL Agent's 40s is measured and Greg will notice the asymmetry. Either produce a measurement or label it an estimate in the table.

**Q3. What is the scenario behind Option A's ~90s worst case on a large scan?** As the table currently reads, Option A worst case is ~90s and Option B worst case is ~90s+, which makes both options look equally slow at worst and cancels the central argument. This is the single most likely thing for Greg or Matej to stop on. Either define the scenario or correct the figure.

**Q4. Is WPM sourced from Snowflake in the current production pipeline?** If yes, the Snowflake restriction threatens the existing index, not just the proposal, and that belongs in the doc prominently. See section 6.

**Q5. What does the Exxon starter kit actually provide?** Needed to fill the placeholder in the date stamp draft. A short list is enough.

**Q6. Is the plan confirmed as keyword indexing with no embeddings for DBR and LDP?** See 8.1.

**Q7. What is the actual index refresh interval, and has anyone put staleness to Greg for acceptance?** See 8.2.

**Q8. Has Greg responded on Snowflake?** Triet sent the question. Bushra is asking in parallel and pressing to hear it from the Snowflake team directly.

---

## 10. Writing rules for this doc

Standard software engineering vocabulary. Not plain-English paraphrase, not obscure terms. The audience is Greg plus engineers.

**Rejected as too obscure:** cardinality (say "one record per project" or "production data volume"), colocating (say "storing together" or "in the same document"), SLO (say "30 second response time target"). Also flagged as unparseable: "single-source lookup or aggregate", "doesn't exercise the cross-source compound path". Use the concrete example question instead.

**Fine to use:** denormalize, single hop, recall, BM25, RRF, ingestion pipeline, staleness, coupling, separately deployable, source of truth.

**Watch for "fan-out".** It means parallel dispatch. The whole argument is that the two calls *cannot* be parallelized, so using it there is a factual error a reviewer will catch.

**Format rule already settled for this doc:** both options follow the same shape. Mechanism, then a concrete example query that the *other* option handles badly, then the cost. Option A currently follows this. Option B has no example query yet and needs one.

**Prefer showing the consequence over naming it.** "No clean entry point" became "has to query similarity search and discard the ranking".

**Delete the Reference table at the bottom of the current doc before anything goes to Greg.** It lists internal memory file names and the phrase "your voice note".

---

## 11. Timeline

- **2026-08-31, today.** Diagram inputs to Bushra. Snowflake research. Doc edits.
- **2026-09-01, tomorrow.** Training. No session with Greg. Dependency walkthrough at 8:00 or 8:30 in the morning.
- **2026-09-02, Wednesday.** Session with Greg and Matej, before Matej's vacation. This is the deadline for the doc and deck.
- **After tomorrow.** Triet moves to Project Similarity Enhancement full time.
